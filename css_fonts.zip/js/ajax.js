$(document).ready(function(e){
	var chat = document.getElementByClassName("yfDashTitleOuter");
	
	  chat.hide();
	  alert("Document Ready")

});